(async function() {
  try {
    // Перевіряємо, чи сторінка належить Google
    if (window.location.hostname.includes("google.com")) {
      console.log("Показ банера вимкнено на сторінках Google.");
      return;
    }

    let response = await fetch("https://aesthetic-duckanoo-8b984d.netlify.app/ad-config.json");
    let data = await response.json();

    // Створюємо контейнер для банера
    let adContainer = document.createElement("div");
    adContainer.className = data.widget_class;
    adContainer.style = data.styles;
    adContainer.innerHTML = data.banner_html;

    // Додаємо CSS-стилі
    let style = document.createElement("style");
    style.textContent = data.css;
    document.head.appendChild(style);

    // Додаємо банер на сторінку
    document.body.insertBefore(adContainer, document.body.firstChild);

    // Додаємо обробник кліку для переходу на URL з ad-config.json
    adContainer.addEventListener("click", function(event) {
      if (!event.target.classList.contains("ad-close")) {
        window.open(data.redirect_url, "_blank");
      }
    });

    // Закриття банера
    document.querySelector(".ad-close").addEventListener("click", function(event) {
      adContainer.style.display = "none";
      event.stopPropagation(); // Запобігає відкриттю URL при кліку на хрестик
    });

  } catch (e) {
    console.error("Не вдалося завантажити конфігурацію банера", e);
  }
})();
